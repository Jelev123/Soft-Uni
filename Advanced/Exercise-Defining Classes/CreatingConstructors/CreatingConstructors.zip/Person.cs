﻿namespace CreatingConstructors
{
    public class Person
    {
        
    }
}