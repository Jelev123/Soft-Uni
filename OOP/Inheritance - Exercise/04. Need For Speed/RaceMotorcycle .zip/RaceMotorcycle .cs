﻿namespace Temp
{
    public class RaceMotorcycle_: Motorcycle
    {
        public RaceMotorcycle_(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
}