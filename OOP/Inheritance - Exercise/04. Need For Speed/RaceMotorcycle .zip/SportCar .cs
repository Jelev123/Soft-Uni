﻿namespace Temp
{
    public class SportCar_:Car
    {
        public SportCar_(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
}