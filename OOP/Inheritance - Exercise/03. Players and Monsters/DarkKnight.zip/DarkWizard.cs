﻿namespace _03._Players_and_Monsters
{
    public class DarkWizard : Wizard
    {
        public DarkWizard(string username, int level) : base(username, level)
        {
        }
    }
}