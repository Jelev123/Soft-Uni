﻿namespace _03._Players_and_Monsters
{
    public class MuseElf : Elf
    {
        public MuseElf(string username, int level) : base(username, level)
        {
        }
    }
}