﻿using System;

namespace _03._Players_and_Monsters
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
