﻿namespace _03._Players_and_Monsters
{
    public class Elf : Hero
    {
        public Elf(string username, int level) : base(username, level)
        {
        }
    }
}