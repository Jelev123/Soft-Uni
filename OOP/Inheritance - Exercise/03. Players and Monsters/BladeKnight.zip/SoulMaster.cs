﻿namespace _03._Players_and_Monsters
{
    public class SoulMaster: DarkWizard

    {
        public SoulMaster(string username, int level) : base(username, level)
        {
        }
    }
}