﻿namespace _03._Players_and_Monsters
{
    public class SoulMaster : Wizard
    {
        public SoulMaster(string name, int level) : base(name, level)
        {
        }
    }
}