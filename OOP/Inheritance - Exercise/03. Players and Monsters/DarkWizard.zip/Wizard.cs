﻿namespace _03._Players_and_Monsters
{
    public class Wizard : Hero
    {
        public Wizard(string name, int level) : base(name, level)
        {
        }
    }
}