﻿namespace _03._Players_and_Monsters
{
    public class MuseElf: Elf

    {
        public MuseElf(string name, int level) : base(name, level)
        {
        }
    }
}