﻿namespace _03._Players_and_Monsters
{
    public class Knight : Hero

    {
        public Knight(string name, int level) : base(name, level)
        {
        }
    }
}