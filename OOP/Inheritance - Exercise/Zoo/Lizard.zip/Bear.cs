﻿namespace Zoo
{
    public class Bear
    {
        
    }
}