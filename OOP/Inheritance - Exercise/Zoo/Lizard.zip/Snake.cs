﻿namespace Zoo
{
    public class Snake
    {
        
    }
}