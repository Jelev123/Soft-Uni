﻿namespace Zoo
{
    public class Animal
    {
        
    }
}