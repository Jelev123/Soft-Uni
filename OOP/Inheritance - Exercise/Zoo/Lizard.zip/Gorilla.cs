﻿namespace Zoo
{
    public class Gorilla
    {
        
    }
}