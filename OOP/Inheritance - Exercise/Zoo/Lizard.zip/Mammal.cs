﻿namespace Zoo
{
    public class Mammal
    {
        
    }
}