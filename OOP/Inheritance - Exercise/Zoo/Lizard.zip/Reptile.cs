﻿namespace Zoo
{
    public class Reptile
    {
        
    }
}