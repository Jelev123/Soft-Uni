﻿namespace Zoo
{
    public class Lizard
    {
        
    }
}