﻿namespace _03._Telephony
{
    public interface IBrowseble
    {
        string Browse(string url);

    }
}