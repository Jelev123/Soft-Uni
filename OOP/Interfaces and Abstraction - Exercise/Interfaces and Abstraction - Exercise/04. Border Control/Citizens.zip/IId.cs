﻿namespace _04._Border_Control
{
    public interface IId
    {
        string Id { get; }
    }
}