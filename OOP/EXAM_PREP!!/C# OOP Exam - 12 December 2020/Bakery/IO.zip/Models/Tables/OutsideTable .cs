﻿namespace Bakery.Models.Tables
{
    public class OutsideTable_: Table
    {
        public OutsideTable_(int tableNumber, int capacity) : base(tableNumber, capacity, 3.50m)
        {
        }
    }
}