﻿using System;

namespace Farm
{
    public class Cat : Animal
    {
        public void Meowing()
        {
            Console.WriteLine("meowing...");
        }
    }
}