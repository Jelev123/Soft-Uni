﻿using System;
using System.Collections.Generic;
using System.IO;
using AutoMapper;
using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using ProductShop.XMLHelper;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext db = new ProductShopContext();

            var xml = File.ReadAllText("../../../Datasets/users.xml");

            var result = ImportUsers(db, xml);

            Console.WriteLine(result);

        }


        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            const string rootElement = "Users";

            var resultXml = XMLConverter.XmlConverter.Deserializer<ImportUsersDTO>(inputXml, rootElement);

            List<User> users = new List<User>();

            foreach (var importUsersDto in resultXml)
            {
                var user = new User
                {
                    FirstName = importUsersDto.FirstName,
                    LastName = importUsersDto.LastName,
                    Age = importUsersDto.Age
                };

                users.Add(user);
            }


            context.Users.AddRange(users);
            context.SaveChanges();
            return $"Successfully imported {users.Count}";

        }




    }
}